package dev.aero.combat;

/** Runtime-tunable values. Everything here is uncalibrated: tune in game with /aero. */
public final class AeroConfig {
	private AeroConfig() {}

	// TriggerBot
	public static double triggerMinCooldown = 0.92;      // attack cooldown progress required, 0..1
	public static boolean triggerPlayersOnly = true;
	public static int triggerMinTicksBetweenHits = 1;

	// AimAssist (angles in degrees)
	public static double aimRange = 4.5;                 // blocks, eye to aim point
	public static double aimFovDegrees = 45.0;           // half-angle of the cone around the current view direction
	public static double aimSmooth = 0.15;               // fraction of the remaining angle closed per tick
	public static double aimMaxStepDegrees = 6.0;        // hard cap per tick
	public static double aimHeightFraction = 0.7;        // aim point height as a fraction of the target's height
	public static boolean aimRequireAttackKey = true;    // only assist while the attack key is held
	public static boolean aimPlayersOnly = true;
}
