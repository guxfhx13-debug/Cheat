package dev.aero.combat.module;

import dev.aero.combat.AeroConfig;
import dev.aero.combat.AimMath;
import dev.aero.combat.Targeting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/** Smoothly turns the view toward the target closest to the crosshair, inside a cone and a range limit. */
public final class AimAssistModule extends Module {
	public AimAssistModule() {
		super("AimAssist", "key.aerocombat.aim", GLFW.GLFW_KEY_G);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null) return;
		if (AeroConfig.aimRequireAttackKey && !client.options.attackKey.isPressed()) return;

		Vec3d eye = player.getEyePos();
		Vec3d look = player.getRotationVec(1.0f);

		Vec3d bestAim = null;
		double bestAngle = Double.MAX_VALUE;

		for (Entity e : client.world.getEntities()) {
			if (!Targeting.isValid(e, player, AeroConfig.aimPlayersOnly)) continue;

			Vec3d aim = new Vec3d(e.getX(), e.getY() + e.getHeight() * AeroConfig.aimHeightFraction, e.getZ());
			Vec3d d = aim.subtract(eye);
			if (d.length() > AeroConfig.aimRange) continue;

			double angle = AimMath.angleBetweenDegrees(look.x, look.y, look.z, d.x, d.y, d.z);
			if (angle > AeroConfig.aimFovDegrees || angle >= bestAngle) continue;
			if (!player.canSee(e)) continue;

			bestAngle = angle;
			bestAim = aim;
		}
		if (bestAim == null) return;

		Vec3d d = bestAim.subtract(eye);
		double dYaw = AimMath.wrapDegrees(AimMath.yawTo(d.x, d.z) - player.getYaw());
		double dPitch = AimMath.pitchTo(d.x, d.y, d.z) - player.getPitch();

		double max = AeroConfig.aimMaxStepDegrees;
		double stepYaw = AimMath.clamp(dYaw * AeroConfig.aimSmooth, -max, max);
		double stepPitch = AimMath.clamp(dPitch * AeroConfig.aimSmooth, -max, max);
		if (Math.abs(stepYaw) < 0.01 && Math.abs(stepPitch) < 0.01) return;

		player.setYaw((float) (player.getYaw() + stepYaw));
		player.setPitch((float) AimMath.clamp(player.getPitch() + stepPitch, -90.0, 90.0));
	}
}
