package dev.aero.combat.module;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

public abstract class Module {
	private final String name;
	private final KeyBinding key;
	private boolean enabled;

	protected Module(String name, String translationKey, int defaultKeyCode) {
		this.name = name;
		this.key = KeyBindingHelper.registerKeyBinding(
			new KeyBinding(translationKey, InputUtil.Type.KEYSYM, defaultKeyCode, "key.categories.aerocombat"));
	}

	public String name() { return name; }
	public KeyBinding key() { return key; }
	public boolean isEnabled() { return enabled; }

	public void setEnabled(boolean value) {
		if (enabled == value) return;
		enabled = value;
		if (!value) onDisable();
	}

	public void toggle() { setEnabled(!enabled); }

	public abstract void onTick(MinecraftClient client);

	protected void onDisable() {}
}
