package dev.aero.combat.module;

import dev.aero.combat.AeroConfig;
import dev.aero.combat.Targeting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

/** Attacks the entity under the crosshair once the weapon cooldown has recovered. Range is vanilla's. */
public final class TriggerBotModule extends Module {
	private long lastHitTick = -1000L;

	public TriggerBotModule() {
		super("TriggerBot", "key.aerocombat.trigger", GLFW.GLFW_KEY_R);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null) return;
		if (player.isUsingItem()) return;

		HitResult hit = client.crosshairTarget;
		if (!(hit instanceof EntityHitResult entityHit)) return;
		Entity target = entityHit.getEntity();
		if (!Targeting.isValid(target, player, AeroConfig.triggerPlayersOnly)) return;

		if (player.getAttackCooldownProgress(0.5f) < AeroConfig.triggerMinCooldown) return;

		long now = client.world.getTime();
		if (now - lastHitTick < AeroConfig.triggerMinTicksBetweenHits) return;

		client.interactionManager.attackEntity(player, target);
		player.swingHand(Hand.MAIN_HAND);
		lastHitTick = now;
	}
}
