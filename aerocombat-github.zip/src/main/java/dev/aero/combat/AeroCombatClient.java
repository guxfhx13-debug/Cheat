package dev.aero.combat;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.aero.combat.module.AimAssistModule;
import dev.aero.combat.module.Module;
import dev.aero.combat.module.TriggerBotModule;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.List;
import java.util.function.DoubleConsumer;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class AeroCombatClient implements ClientModInitializer {
	private static final TriggerBotModule TRIGGER = new TriggerBotModule();
	private static final AimAssistModule AIM = new AimAssistModule();
	private static final List<Module> MODULES = List.of(TRIGGER, AIM);

	@Override
	public void onInitializeClient() {
		ClientTickEvents.END_CLIENT_TICK.register(AeroCombatClient::onTick);
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
			dispatcher.register(literal("aero")
				.then(literal("status").executes(ctx -> {
					ctx.getSource().sendFeedback(Text.literal(status()));
					return 1;
				}))
				.then(literal("trigger").executes(ctx -> toggle(ctx.getSource(), TRIGGER)))
				.then(literal("aim").executes(ctx -> toggle(ctx.getSource(), AIM)))
				.then(numeric("fov", 1, 180, v -> AeroConfig.aimFovDegrees = v))
				.then(numeric("smooth", 0.01, 1, v -> AeroConfig.aimSmooth = v))
				.then(numeric("maxstep", 0.1, 90, v -> AeroConfig.aimMaxStepDegrees = v))
				.then(numeric("range", 1, 8, v -> AeroConfig.aimRange = v))
				.then(numeric("cooldown", 0, 1, v -> AeroConfig.triggerMinCooldown = v))));
	}

	private static void onTick(MinecraftClient client) {
		for (Module m : MODULES) {
			while (m.key().wasPressed()) {
				m.toggle();
				if (client.player != null) {
					client.player.sendMessage(Text.literal(m.name() + ": " + (m.isEnabled() ? "ON" : "OFF")), true);
				}
			}
		}
		if (client.player == null || client.world == null) {
			for (Module m : MODULES) m.setEnabled(false);
			return;
		}
		if (client.currentScreen != null || !client.isWindowFocused() || client.player.isSpectator()) return;
		for (Module m : MODULES) {
			if (m.isEnabled()) m.onTick(client);
		}
	}

	private static int toggle(FabricClientCommandSource src, Module m) {
		m.toggle();
		src.sendFeedback(Text.literal(m.name() + ": " + (m.isEnabled() ? "ON" : "OFF")));
		return 1;
	}

	private static LiteralArgumentBuilder<FabricClientCommandSource> numeric(
			String name, double min, double max, DoubleConsumer setter) {
		return literal(name).then(argument("value", DoubleArgumentType.doubleArg(min, max)).executes(ctx -> {
			double v = DoubleArgumentType.getDouble(ctx, "value");
			setter.accept(v);
			ctx.getSource().sendFeedback(Text.literal(name + " = " + v));
			return 1;
		}));
	}

	private static String status() {
		return String.format(
			"TriggerBot=%s (cooldown %.2f) | AimAssist=%s (fov %.1f, smooth %.2f, maxstep %.1f, range %.1f)",
			TRIGGER.isEnabled() ? "ON" : "OFF", AeroConfig.triggerMinCooldown,
			AIM.isEnabled() ? "ON" : "OFF", AeroConfig.aimFovDegrees, AeroConfig.aimSmooth,
			AeroConfig.aimMaxStepDegrees, AeroConfig.aimRange);
	}
}
