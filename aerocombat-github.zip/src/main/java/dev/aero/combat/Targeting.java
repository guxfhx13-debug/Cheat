package dev.aero.combat;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;

public final class Targeting {
	private Targeting() {}

	public static boolean isValid(Entity e, ClientPlayerEntity self, boolean playersOnly) {
		if (e == null || e == self) return false;
		if (!(e instanceof LivingEntity living)) return false;
		if (e instanceof ArmorStandEntity) return false;
		if (!living.isAlive() || living.isSpectator()) return false;
		if (playersOnly && !(e instanceof PlayerEntity)) return false;
		return Double.isFinite(e.getX()) && Double.isFinite(e.getY()) && Double.isFinite(e.getZ());
	}
}
