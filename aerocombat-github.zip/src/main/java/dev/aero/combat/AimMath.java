package dev.aero.combat;

/**
 * Pure math, no Minecraft classes.
 * Minecraft convention: yaw 0 looks toward +Z, yaw 90 toward -X; pitch +90 looks straight down. Degrees.
 */
public final class AimMath {
	private AimMath() {}

	public static double wrapDegrees(double a) {
		double r = a % 360.0;
		if (r >= 180.0) r -= 360.0;
		if (r < -180.0) r += 360.0;
		return r;
	}

	public static double yawTo(double dx, double dz) {
		return Math.toDegrees(Math.atan2(-dx, dz));
	}

	public static double pitchTo(double dx, double dy, double dz) {
		return -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
	}

	/** Angle between two direction vectors; 180 if either is degenerate or non-finite. */
	public static double angleBetweenDegrees(double ax, double ay, double az, double bx, double by, double bz) {
		double la = Math.sqrt(ax * ax + ay * ay + az * az);
		double lb = Math.sqrt(bx * bx + by * by + bz * bz);
		if (!Double.isFinite(la) || !Double.isFinite(lb) || la < 1e-9 || lb < 1e-9) return 180.0;
		double dot = (ax * bx + ay * by + az * bz) / (la * lb);
		dot = Math.max(-1.0, Math.min(1.0, dot));
		return Math.toDegrees(Math.acos(dot));
	}

	public static double clamp(double v, double lo, double hi) {
		return Math.max(lo, Math.min(hi, v));
	}
}
