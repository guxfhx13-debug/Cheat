# AeroCombat (Fabric, Minecraft 1.21.4, Yarn mappings)

Build: `gradle wrapper --gradle-version 8.12` (once), then `./gradlew build` (Windows: `gradlew.bat build`), JDK 21.
Output: `build/libs/aerocombat-1.0.0.jar` (not the `-sources` one). Put it in `.minecraft/mods` with Fabric API.

Keys: R toggles TriggerBot, G toggles AimAssist (rebind in Controls). Commands: /aero status|trigger|aim|fov|smooth|maxstep|range|cooldown.
Tip: if versions in gradle.properties fail to resolve, generate a template at https://fabricmc.net/develop (1.21.4, Yarn)
and copy `src/` into it.
